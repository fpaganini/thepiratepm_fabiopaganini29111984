Complete name:   
Time zone:     
Birthday:  
Github:   
Linkedin:  
Codwars:   
Stackoverflow:   

*** 

**Based only in company culture,   
As a Project Manager who works with software and web development   
which of the following companies would you like to work for?**

( ) Google  
( ) Buffer  
( ) Automattic  
( ) Microsoft  
( ) IBM   
( ) Basecamp (former 37signals)  
( ) Apple  
( ) None of the above  

***

**Based on the type and quality of product(s) delivered,   
As a Project Manager  
which of the following companies would you like to work for?**

( ) Google  
( ) Buffer  
( ) Automattic  
( ) Microsoft  
( ) IBM   
( ) Basecamp (former 37signals)  
( ) Apple  
( ) None of the above  

***

**In order to deliver working software early and often,   
As a Project Manager   
Which of the following do you believe is more important?**  

( ) Individuals and interactions over processes and tools  
( ) Working software over comprehensive documentation  
( ) Customer collaboration over contract negotiation  
( ) Responding to change over following a plan  
( ) None of the above   

***

**In order to stronger my analytical thinking skills and to have fun  
As a Project Manager  
I've read the following books:**
 
[ ] Peopleware: Productive Projects and Teams  
[ ] The Mythical Man-Month  
[ ] Extreme Programming Explained  
[ ] Waltzing with Bears  
[ ] Microserfs  
[ ] Slack  
[ ] Death March  
[ ] Bridging the Communication Gap  
[ ] Adrenaline Junkies and Template Zombies   
[ ] Project Management For Dummies  
[ ] The Lazy Project Manager  
[ ] The Agile Samurai  
[ ] Rework  
[ ] The Principles of Product Development Flow  
[ ] Managing the Unmanageable  
[ ] The Toyota Way  

*** 

**As a Project Manager  
My favorite of the following books is:**

( ) Peopleware: Productive Projects and Teams  
( ) The Mythical Man-Month  
( ) Extreme Programming Explained  
( ) Waltzing with Bears  
( ) Microserfs  
( ) Slack  
( ) Death March  
( ) Bridging the Communication Gap  
( ) Adrenaline Junkies and Template Zombies   
( ) Project Management For Dummies  
( ) The Lazy Project Manager  
( ) The Agile Samurai  
( ) Rework  
( ) The Principles of Product Development Flow  
( ) Managing the Unmanageable  
( ) The Toyota Way  
( ) I haven't read any of them

*** 

**When it comes to Software Development,
As a Project Manager  
My favorite of the following speakers is:** 

( ) Uncle Bob  
( ) Dr. Russell Ackoff  
( ) Gojko Adzic  
( ) Martin Fowler  
( ) Dave Snowden  
( ) Jason Fried  
( ) Don Reinertsen  
( ) I don't know any of them  

*** 

**In order to relax, concentrate and entertain myself,  
As a Project Manager  
I like to listen to:** 

( ) Vulgar Display of Power, Pantera  
( ) Reign in Blood, Slayer   
( ) Paranoid, Black Sabbath  
( ) Raw Power, Iggy and the Stooges  
( ) Damaged, Black Flag  
( ) Ramones, Ramones  
( ) Believe, Justin Bieber  
( ) Actually, I prefer to follow Matt Mullenweg on Spotify  
( ) Actually, I believe it's not appropiate to hear music during working hours  
( ) None of the above  

***

**As a Project Manager  
Wich of the following is your favorite tv show:** 

( ) The IT Crowd  
( ) Silicon Valley    
( ) Doctor Who   
( ) Star Trek The Next Generation
( ) Start Trek Original Series 
( ) Game of Thrones

***

**As a Project Manager  
Wich of the following is your favorite tv show:** 

( ) Melisandre   
( ) Cersei Lannister  
( ) Joffrey Baratheon  
( ) Ramsay Bolton  
( ) Petyr Baelish  
( ) I don't like GoT  
( ) I hate GoT
( ) I don't watch GoT and don't know any of these characters   
( ) I watch GoT, but I don't identify myself with any of these characters  
