**Full name:   
Time zone:     
Birthday:  
Github:   
Linkedin:  
Codwars:   
Stackoverflow:**

*** 

**Based only in company culture,    
As a Project Manager     
I would like to work for**  

( ) Google  
( ) Buffer  
( ) Automattic  
( ) Microsoft  
( ) IBM   
( ) Basecamp (former 37signals)  
( ) Apple  
( ) None of the above  

***  

**Based only on the type of product delivered,   
As a Project Manager  
I would like to work for**  

( ) Google  
( ) Buffer  
( ) Automattic  
( ) Microsoft  
( ) IBM   
( ) Basecamp (former 37signals)  
( ) Apple  
( ) None of the above  

***

**In order to deliver working software early and often,   
As a Project Manager   
I believe the most important variable is**  

( ) Individuals and interactions over processes and tools  
( ) Working software over comprehensive documentation  
( ) Customer collaboration over contract negotiation  
( ) Responding to change over following a plan  
( ) None of the above   

***

**In order to have some fun  
As a Project Manager  
I've read the following books**
 
[ ] Peopleware: Productive Projects and Teams  
[ ] The Mythical Man-Month  
[ ] Extreme Programming Explained  
[ ] Waltzing with Bears  
[ ] Microserfs  
[ ] Slack  
[ ] Death March  
[ ] Bridging the Communication Gap  
[ ] Adrenaline Junkies and Template Zombies   
[ ] Project Management For Dummies  
[ ] The Lazy Project Manager  
[ ] The Agile Samurai  
[ ] Rework  
[ ] The Principles of Product Development Flow  
[ ] Managing the Unmanageable  
[ ] The Toyota Way   
[ ] Managing the Unmanageable  

*** 

**As a Project Manager  
My favorite of the following books is**

( ) Peopleware: Productive Projects and Teams  
( ) The Mythical Man-Month  
( ) Extreme Programming Explained  
( ) Waltzing with Bears  
( ) Microserfs  
( ) Slack  
( ) Death March  
( ) Bridging the Communication Gap  
( ) Adrenaline Junkies and Template Zombies   
( ) Project Management For Dummies  
( ) The Lazy Project Manager  
( ) The Agile Samurai  
( ) Rework  
( ) The Principles of Product Development Flow  
( ) Managing the Unmanageable  
( ) The Toyota Way  
( ) Managing the Unmanageable  
( ) I haven't read any of them

*** 

**When it comes to Software Development,  
As a Project Manager  
My favorite of the following speakers is** 

( ) Uncle Bob  
( ) Dr. Russell Ackoff  
( ) Gojko Adzic  
( ) Martin Fowler  
( ) Dave Snowden  
( ) Jason Fried  
( ) Don Reinertsen  
( ) I don't know any of them  

*** 

**In order to relax,  
As a Project Manager  
I love to listen to** 

( ) Vulgar Display of Power, Pantera  
( ) Reign in Blood, Slayer   
( ) Paranoid, Black Sabbath  
( ) Raw Power, Iggy and the Stooges  
( ) Damaged, Black Flag  
( ) Ramones, Ramones  
( ) Believe, Justin Bieber  
( ) Actually, I prefer to follow Matt Mullenweg on Spotify  
( ) Actually, I believe it's not appropiate to hear music during working hours  
( ) None of the above  

***

**As a Project Manager  
My favorite tv show is**  

( ) The IT Crowd  
( ) Silicon Valley    
( ) Doctor Who   
( ) Star Trek The Next Generation   
( ) Keeping Up With The Kardashians  
( ) Start Trek Original Series    
( ) Game of Thrones  
( ) The Apprentice  
( ) Shark Tank  
( ) Ramsay's Kitchen Nightmares  
( ) Techstars  

***

**As a Project Manager  
My favorite GoT character is** 

( ) Melisandre   
( ) Cersei Lannister  
( ) Joffrey Baratheon  
( ) Ramsay Bolton  
( ) Petyr Baelish  
( ) I don't like GoT  
( ) I hate GoT  
( ) I don't watch GoT and don't know any of mentioned characters   
( ) I watch GoT, but I don't identify myself with any of mentioned characters  

***

**As a Project Manager   
I would like to have in my team**

[ ] Ironman  
[ ] The Hulk  
[ ] Batman  
[ ] Aquaman  
[ ] Scott Pilgrim    

***

**As a Project Manager   
I would like to have in my team**

( ) Ironman  
( ) The Hulk  
( ) Batman  
( ) Aquaman  
( ) Scott Pilgrim    

***

**As a Project Manager  
I always have faith in the process**   

[ ] True  
[ ] False  

***

**As a Project Manager  
I believe the most unhelpful document from the following is**   

[ ] Business Case    
[ ] Statement of Work   
[ ] Project Charter  
[ ] Lessons Learned  
[ ] Meeting Minutes  
[ ] I don't know any of the above documents.   
[ ] All documents are unhelpful for Software PM. I hate them all.  
[ ] All documents cab be very helpful and worth the time. I love the all.

***

**As a Project Manager  
My favorite from the following movies is**   

[ ] Tron      
[ ] Hackers    
[ ] Office Space     
[ ] WarGames    
[ ] The Hitchhiker's Guide to the Galaxy    
[ ] Weird Science    
[ ] Revenge of the Nerds   
[ ] Galaxy Quest  
[ ] The Iron Giant  
[ ] Ferris Bueller's Day Off  	
[ ] Gattaca  
[ ] Knights of Badassdom  

***

**As a Project Manager   
My favorite PM tool is**  

[ ] Excel  
[ ] Google Docs   
[ ] Slack  
[ ] Skype  
[ ] Google Hangouts  
[ ] My e-mail client  
[ ] MS-Project   
[ ] JIRA  
[ ] Basecamp  
[ ] A stapler   
[ ] Paper clips    

***

**As a Project Manager  
I always have faith in people**   

[ ] True  
[ ] False  

***

**When using Git,   
I find a list of files that has changed in a particular commit**

>  Your answer here...  

***

**As a Project Manager   
I don't want to work on**  

>  Your answer here...  

***

**As a Project Manager  
When I am not working     
I spend the most time doing***

>  Your answer here...  

***

**As a Project Manager   
IMO the perfect software engineering process would be like**

>  Your answer here...  

***