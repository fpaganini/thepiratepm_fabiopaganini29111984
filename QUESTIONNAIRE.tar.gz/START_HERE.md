- First of all, make a copy of the file `questionnaire.md`. Name it "questionnaire_[yourfirstandlastnamebirthdayDDMMYYYY].md"

> E.g.: given that my name is Ânderson Quadros and my birthday is May 06, 1977, I should name the file `questionnaire_andersonquadros06051977.md`.  	

- Open the newly created file and answer the questions. 
- Use the capital letter `X` between the square brackets and parenthesis to mark your answers.
	- Consider square brackets as checkboxes. 
	- Consider parenthesis as radio buttons.
	- Blockquotes are for free-answers.  
- When answering the questionnaire, don't worry with answering all the questions, but be fully honesty on all your answers.    
- After answering all questions, substitute the original `QUESTIONNAIRE.tar.gz` package with a new package, archiving the new file (i.e. your answers) along the original files. The content of the new package should looks like this:

> questionnaire.md   
questionnaire_andersonquadros05061977.md  
START_HERE.md  

* And your local repo should looks like that:

> LICENSE  
README.md  
QUESTIONNAIRE.tar.gz  

* Rename you local branch following the pattern below.

> thepiratepm_[yourfirstandlastnamebirthdayDDMMYYYY] 

* Delete the old branch.  
* Push the new branch.
* Open a pull request. That's all :-)
