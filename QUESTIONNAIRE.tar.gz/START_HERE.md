1. First of all, make a copy of the file `questionnaire.md`. Name it "questionnaire_[yourfirstandlastnamebirthdayDDMMYYYY].md"

> E.g.: given that my name is Ânderson Quadros and my birthday is May 06, 1977, I should name the file `questionnaire_andersonquadros06051977.md`.  	

2. Open the newly created file and answer the questions. 
3. Use the capital letter `X` between the square brackets and parenthesis to mark your answers.
4. Consider square brackets as checkboxes. 
5. Consider parenthesis as radio buttons.
6. Blockquotes are for free-answers.  
6. When answering the questions, don't worry in answering all of them. Honesty is way more important.  Plus, it's pretty easy to spot lies ;-)  
7. After answering all questions, substitute the original `QUESTIONNAIRE.tar.gz` package with a new package, archiving the new file (i.e. your answers) along the original files. The content of the new package should looks like that:

> questionnaire.md   
questionnaire_andersonquadros05061977.md  
START_HERE.md  

* And you local repository should looks like that:

> LICENSE  
README.md  
QUESTIONNAIRE.tar.gz  

* Push the changes to your Github repository.
* Open a pull request. That's all :-)
