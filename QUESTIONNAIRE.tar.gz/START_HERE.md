* First of all, make a copy of the file `questionnaire.md`. Name it "questionnaire_[yourfirstandlastnamebirthday].md"

> E.g.: given that my name is Ânderson Quadros and my birthday is May 06, 1977, I should name the file `questionnaire_andersonquadros05061977.md`.  	

* Open the newly created file and answer the questions. 
* Use the capital letter `X` between the square brackets and parenthesis to mark your answers.
* Consider square brackets as checkboxes. 
* Consider parenthesis as radio buttons.
* After answering all questions, substitute the original `QUESTIONNAIRE.tar.gz` package with a new package, archiving the new file (i.e. your answers) along with the original files. The content of the new package should looks like that:

> questionnaire.md   
questionnaire_andersonquadros05061977.md  
START_HERE.md  

* And you local repository should looks like that:

> LICENSE  
README.md  
QUESTIONNAIRE.tar.gz  

* Push the changes to your Github repository.
* Open a pull request. That's all :-)
